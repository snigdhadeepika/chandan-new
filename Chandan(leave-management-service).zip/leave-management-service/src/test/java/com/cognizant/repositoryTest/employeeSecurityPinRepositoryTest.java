
package com.cognizant.repositoryTest; 
import com.cognizant.LeaveManagementServiceApplication;
import com.cognizant.entities.Employee;
import com.cognizant.entities.EmployeeSecurityPin;
import com.cognizant.repositories.EmployeeSecurityPinRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.time.LocalDate;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
 
@DataJpaTest

@ContextConfiguration(classes = LeaveManagementServiceApplication.class)

public class employeeSecurityPinRepositoryTest {

    @Autowired

    private EmployeeSecurityPinRepository employeeSecurityPinRepository;
 
   // @Autowired

   // private EmployeeRepository employeeRepository;
 
    @Autowired

    private TestEntityManager entityManager;
 
    private Employee createMockEmployee(String id) {

        Employee employee = new Employee();

        employee.setId(id);

        employee.setFirstName("Test");

        employee.setLastName("Employee");

        employee.setEmail("test@example.com");

        employee.setPhone("1234567890");

        employee.setJoinedon(LocalDate.now());

        employee.setEmployeeBand("A1");

        employee.setLocation("Test City");

        employee.setRole("Developer");

        return entityManager.persistAndFlush(employee);

    }
 
    private EmployeeSecurityPin createAndPersistEmployeeSecurityPin(String employeeId, Integer pin) {

        Employee employee = createMockEmployee(employeeId);

        EmployeeSecurityPin employeeSecurityPin = new EmployeeSecurityPin();

        employeeSecurityPin.setPin(pin);

        employeeSecurityPin.setEmployees(employee);

        return entityManager.persistAndFlush(employeeSecurityPin);

    }
 
    @Test

    public void testFindAllPositive() {

        createAndPersistEmployeeSecurityPin("emp001", 1234);

        Iterable<EmployeeSecurityPin> iterable = employeeSecurityPinRepository.findAll();

        assertTrue(iterable.iterator().hasNext());

    }
 
    @Test

    public void testFindByIdPositive() {

        EmployeeSecurityPin employeeSecurityPin = createAndPersistEmployeeSecurityPin("emp002", 5678);
 
        Optional<EmployeeSecurityPin> foundEntity = employeeSecurityPinRepository.findById(employeeSecurityPin.getId());

        assertTrue(foundEntity.isPresent());

    }
 
    @Test

    public void testSavePositive() {

        Employee mockEmployee = createMockEmployee("emp003");

        EmployeeSecurityPin employeeSecurityPin = new EmployeeSecurityPin();

        employeeSecurityPin.setPin(91011);

        employeeSecurityPin.setEmployees(mockEmployee);
 
        EmployeeSecurityPin savedEntity = employeeSecurityPinRepository.save(employeeSecurityPin);

        assertNotNull(savedEntity);

        assertEquals(91011, savedEntity.getPin());

    }
 
    @Test

    public void testDeletePositive() {

        EmployeeSecurityPin employeeSecurityPin = createAndPersistEmployeeSecurityPin("emp004", 121314);
 
        employeeSecurityPinRepository.delete(employeeSecurityPin);

        Optional<EmployeeSecurityPin> foundEntity = employeeSecurityPinRepository.findById(employeeSecurityPin.getId());

        assertFalse(foundEntity.isPresent());

    }

}

