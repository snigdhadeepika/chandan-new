
	package com.cognizant.repositoryTest;
	 
	import com.cognizant.LeaveManagementServiceApplication;
	import com.cognizant.entities.Employee;
	import com.cognizant.repositories.EmployeeRepository;
	import org.junit.jupiter.api.Test;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
	import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
	import org.springframework.test.context.ContextConfiguration;
	 
	import java.util.Optional;
import java.time.LocalDate;

	 
	import static org.junit.jupiter.api.Assertions.*;
	 
	@DataJpaTest
	@ContextConfiguration(classes = LeaveManagementServiceApplication.class)
	public class employeeRepositoryTest {
	 
	    @Autowired
	    private EmployeeRepository employeeRepository;
	 
	    @Autowired
	    private TestEntityManager entityManager;
	 
	    @Test
	    public void testFindAllPositive() {
	        Employee employee = new Employee();
	        employee.setId("emp001");
	        employee.setFirstName("John");
	        employee.setLastName("Doe");
	        employee.setEmail("johndoe@example.com");
	        employee.setPhone("1234567890");
	        employee.setJoinedon(LocalDate.now()); // Use appropriate date
	        employee.setEmployeeBand("A1");
	        employee.setLocation("Hyderabad");
	        employee.setRole("Developer");
	 
	        entityManager.persist(employee);
	 
	        Iterable<Employee> iterable = employeeRepository.findAll();
	        assertTrue(iterable.iterator().hasNext());
	    }
	 
	    @Test
	    public void testFindByIdPositive() {
	        Employee employee = new Employee();
	        employee.setId("emp002");
	        employee.setFirstName("Jane");
	        employee.setLastName("Doe");
	        employee.setEmail("janedoe@example.com");
	        employee.setPhone("0987654321");
	        employee.setJoinedon(LocalDate.now()); // Use appropriate date
	        employee.setEmployeeBand("B1");
	        employee.setLocation("Pune");
	        employee.setRole("Tester");
	 
	        entityManager.persist(employee);
	 
	        Optional<Employee> foundEmployee = employeeRepository.findById("emp002");
	        assertTrue(foundEmployee.isPresent());
	    }
	 
	    @Test
	    public void testSavePositive() {
	        Employee employee = new Employee();
	        employee.setId("emp003");
	        employee.setFirstName("Alice");
	        employee.setLastName("Smith");
	        employee.setEmail("alicesmith@example.com");
	        employee.setPhone("1234509876");
	        employee.setJoinedon(LocalDate.now()); // Use appropriate date
	        employee.setEmployeeBand("C1");
	        employee.setLocation("Bengaluru");
	        employee.setRole("Manager");
	 
	        Employee savedEmployee = employeeRepository.save(employee);
	 
	        assertNotNull(savedEmployee);
	        assertEquals("Alice", savedEmployee.getFirstName());
	    }
	 
	    @Test
	    public void testDeletePositive() {
	        Employee employee = new Employee();
	        employee.setId("emp004");
	        employee.setFirstName("Bob");
	        employee.setLastName("Brown");
	        employee.setEmail("bobbrown@example.com");
	        employee.setPhone("6789054321");
	        employee.setJoinedon(LocalDate.now()); // Use appropriate date
	        employee.setEmployeeBand("L1");
	        employee.setLocation("Chennai");
	        employee.setRole("Lead");
	 
	        Employee persistedEmployee = entityManager.persistFlushFind(employee);
	 
	        employeeRepository.delete(persistedEmployee);
	 
	        Optional<Employee> foundEmployee = employeeRepository.findById("emp004");
	        assertFalse(foundEmployee.isPresent());
	    }
	}
