package com.cognizant.repositoryTest;
 
import com.cognizant.LeaveManagementServiceApplication;
import com.cognizant.entities.Employee;
import com.cognizant.entities.LeavesRegister;
import com.cognizant.repositories.LeavesRegisterRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;
 
import java.time.LocalDate;
import java.util.Optional;
 
import static org.junit.jupiter.api.Assertions.*;
 
@DataJpaTest
@ContextConfiguration(classes = LeaveManagementServiceApplication.class)
public class leavesRegisterRepositoryTest {
 
    @Autowired
    private LeavesRegisterRepository leavesRegisterRepository;
 
    @Autowired
    private TestEntityManager entityManager;
 
    private Employee createMockEmployee(String identifier) {
        Employee employee = new Employee();
        employee.setId("EMP" + identifier); // Ensure unique identifier for each test case
        employee.setFirstName("John" + identifier);
        employee.setLastName("Doe" + identifier);
        employee.setEmail("john.doe" + identifier + "@example.com");
        // Assuming the existence of these fields, adjust accordingly
        return entityManager.persistAndFlush(employee);
    }
 
    private LeavesRegister createAndPersistLeave(Employee employee, LocalDate leaveDate, int numberOfDays, String leaveType) {
        LeavesRegister leave = new LeavesRegister();
        leave.setEmployees(employee);
        leave.setLeaveDate(leaveDate);
        leave.setNumberofDays(numberOfDays);
        leave.setLeaveType(leaveType);
        return entityManager.persistAndFlush(leave);
    }
 
    @Test
    public void testFindAllPositive() {
        Employee employee = createMockEmployee("1");
        createAndPersistLeave(employee, LocalDate.now(), 5, "Annual");
 
        Iterable<LeavesRegister> iterable = leavesRegisterRepository.findAll();
        assertTrue(iterable.iterator().hasNext());
    }
 
    @Test
    public void testFindByIdPositive() {
        Employee employee = createMockEmployee("2");
        LeavesRegister savedLeave = createAndPersistLeave(employee, LocalDate.now().plusDays(10), 3, "Sick");
 
        Optional<LeavesRegister> foundLeave = leavesRegisterRepository.findById(savedLeave.getId());
        assertTrue(foundLeave.isPresent());
    }
 
    @Test
    public void testSavePositive() {
        Employee employee = createMockEmployee("3");
        LeavesRegister leave = new LeavesRegister();
        leave.setEmployees(employee);
        leave.setLeaveDate(LocalDate.now().plusDays(15));
        leave.setNumberofDays(2);
        leave.setLeaveType("Casual");
 
        LeavesRegister savedLeave = leavesRegisterRepository.save(leave);
        assertNotNull(savedLeave);
        assertEquals("Casual", savedLeave.getLeaveType());
    }
 
    @Test
    public void testDeletePositive() {
        Employee employee = createMockEmployee("4");
        LeavesRegister leaveToBeDeleted = createAndPersistLeave(employee, LocalDate.now().plusDays(20), 4, "Emergency");
 
        leavesRegisterRepository.delete(leaveToBeDeleted);
        Optional<LeavesRegister> foundLeave = leavesRegisterRepository.findById(leaveToBeDeleted.getId());
        assertFalse(foundLeave.isPresent());
    }
}