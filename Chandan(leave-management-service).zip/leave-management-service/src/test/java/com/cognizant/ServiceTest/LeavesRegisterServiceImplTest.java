package com.cognizant.ServiceTest;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
 
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
 
import com.cognizant.dto.LeaveReportDTO;
import com.cognizant.dto.LeavesRegisterDTO;
import com.cognizant.entities.Employee;
import com.cognizant.entities.LeavesRegister;
import com.cognizant.repositories.EmployeeRepository;
import com.cognizant.repositories.LeavesRegisterRepository;
import com.cognizant.service.LeavesRegisterServiceImpl;
 
@ExtendWith(MockitoExtension.class)
class LeavesRegisterServiceImplTest {
 
    @Mock
    private LeavesRegisterRepository leavesRegisterRepository;
 
    @Mock
    private EmployeeRepository employeeRepository;
 
    @InjectMocks
    private LeavesRegisterServiceImpl leavesRegisterService;
 
    @Test
    void testAddLeaveDetails() {
        // Mock input DTO
        LeavesRegisterDTO leaveDto = new LeavesRegisterDTO();
        leaveDto.setEmployeeId("1");
        leaveDto.setLeaveDate(LocalDate.now());
        leaveDto.setNumberOfDays(5);
        leaveDto.setLeaveType("Annual");
 
        // Mock Employee entity
        Employee employee = new Employee();
        employee.setId("1");
 
        // Mock repository behavior
        when(employeeRepository.findById("1")).thenReturn(Optional.of(employee));
 
        // Call the service method
        leavesRegisterService.addLeaveDetails(leaveDto);
 
        // Verify that save method is called with correct parameters
        verify(leavesRegisterRepository).save(any(LeavesRegister.class));
    }
 
    @Test
    void testGenerateLeaveReport() {
        // Mock LeavesRegister entities
        LeavesRegister leave1 = new LeavesRegister();
        leave1.setEmployees(new Employee());
        leave1.getEmployees().setId("1");
        leave1.setLeaveDate(LocalDate.now());
        leave1.setNumberofDays(5);
 
        LeavesRegister leave2 = new LeavesRegister();
        leave2.setEmployees(new Employee());
        leave2.getEmployees().setId("2");
        leave2.setLeaveDate(LocalDate.now().minusDays(10));
        leave2.setNumberofDays(3);
 
        // Mock repository behavior
        when(leavesRegisterRepository.findAll()).thenReturn(List.of(leave1, leave2));
 
        // Call the service method
        LocalDate startDate = LocalDate.now().minusDays(15);
        LocalDate endDate = LocalDate.now().minusDays(5);
        List<LeaveReportDTO> report = leavesRegisterService.generateLeaveReport(startDate, endDate);
 
        // Verify the report contains expected entries
        assertEquals(1, report.size());
        assertEquals("1", report.get(0).getEmployeeId());
        assertEquals(startDate, report.get(0).getStartDate());
        assertEquals(endDate, report.get(0).getEndDate());
        assertEquals(5, report.get(0).getLeaveCount());
    }
}