package com.cognizant.ServiceTest;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import com.cognizant.dto.EmployeePinDTO;
import com.cognizant.entities.Employee;
import com.cognizant.entities.EmployeeSecurityPin;
import com.cognizant.repositories.EmployeeRepository;
import com.cognizant.repositories.EmployeeSecurityPinRepository;
import com.cognizant.service.EmployeeSecurityPinServiceImpl;
//import static org.mockito.Mockito.when;
//import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Arrays;
import java.util.List;
//import org.junit.jupiter.api.Test;
 
@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class EmployeeSecurityPinServiceImplTest {
 
    @Mock
    private EmployeeRepository employeeRepository;
 
    @Mock
    private EmployeeSecurityPinRepository securityPinRepository;
 
    @InjectMocks
    private EmployeeSecurityPinServiceImpl service;
 
    @BeforeEach
    public void setUp() {
        // This is handled by @ExtendWith(MockitoExtension.class)
    }
 
    @Test
    public void testCreateEmployeeWithPIN() {
        Employee mockEmployee = new Employee();
        mockEmployee.setId("emp001");
        mockEmployee.setFirstName("John");
 
        EmployeeSecurityPin mockPin = new EmployeeSecurityPin(1234, mockEmployee);
 
        when(employeeRepository.save(any(Employee.class))).thenReturn(mockEmployee);
        when(securityPinRepository.save(any(EmployeeSecurityPin.class))).thenReturn(mockPin);
 
        EmployeePinDTO dto = new EmployeePinDTO();
        dto.setId("emp001");
        dto.setFirstname("John");
        dto.setPin(1234);
 
        EmployeePinDTO resultDto = service.createEmployeeWithPIN(dto);
 
        assertEquals("John", resultDto.getFirstname());
        assertEquals(Integer.valueOf(1234), resultDto.getPin());
    }

 
    @Test
    public void testValidateEmployeePIN_Success() {
        Employee mockEmployee = new Employee();
        mockEmployee.setId("emp001");
        EmployeeSecurityPin mockPin = new EmployeeSecurityPin(1234, mockEmployee);
 
        List<EmployeeSecurityPin> pins = Arrays.asList(mockPin);
 
        when(securityPinRepository.findAll()).thenReturn(pins);
 
        String result = service.validateEmployeePIN("emp001", 1234);
        assertEquals("success", result);
    }
 
    @Test
    public void testValidateEmployeePIN_Fail() {
        Employee mockEmployee = new Employee();
        mockEmployee.setId("emp002");
        EmployeeSecurityPin mockPin = new EmployeeSecurityPin(5678, mockEmployee);
 
        List<EmployeeSecurityPin> pins = Arrays.asList(mockPin);
 
        when(securityPinRepository.findAll()).thenReturn(pins);
 
        String result = service.validateEmployeePIN("emp002", 1234);
        assertEquals("fail", result);
    }
}