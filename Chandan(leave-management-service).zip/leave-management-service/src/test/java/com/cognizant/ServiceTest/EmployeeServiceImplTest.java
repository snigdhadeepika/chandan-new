package com.cognizant.ServiceTest;
//import com.cognizant.dto.EmployeeDTO;
//import com.cognizant.entities.Employee;
//import com.cognizant.exception.EmployeeNotFoundException;
//import com.cognizant.repositories.EmployeeRepository;
//import com.cognizant.service.EmployeeServiceImpl;
//import jakarta.persistence.EntityNotFoundException;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import java.time.LocalDate;
//import java.util.Optional;
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.when;
//@ExtendWith(MockitoExtension.class)
//public class EmployeeServiceImplTest {
// 
//    @Mock
//
//    private EmployeeRepository employeeRepository;
// 
//    @InjectMocks
//    private EmployeeServiceImpl employeeService;
//    private Employee mockEmployee;
// 
//    @BeforeEach
//    public void setUp() {
//
//        mockEmployee = new Employee();
//        mockEmployee.setId("1");
//        mockEmployee.setFirstName("John");
//        mockEmployee.setLastName("Doe");
//        mockEmployee.setEmail("john.doe@example.com");
//        mockEmployee.setPhone("1234567890");
//        mockEmployee.setJoinedon(LocalDate.of(2022, 1, 1));         
//        mockEmployee.setEmployeeBand("A1");    
//        mockEmployee.setLocation("New York");     
//        mockEmployee.setRole("Software Developer"); }
//
//@Test
//
//public void testGetEmployeeById_Found() throws EmployeeNotFoundException {
//
//    when(employeeRepository.findById(anyString())).thenReturn(Optional.of(mockEmployee));
//    EmployeeDTO resultDTO = employeeService.getEmployeeById("1");
//    assertNotNull(resultDTO);
//    assertEquals("John", resultDTO.getFirstname());
//    assertEquals("Doe", resultDTO.getLastname());
//    assertEquals("john.doe@example.com", resultDTO.getEmail());
//    assertEquals("1234567890", resultDTO.getPhone());
//    assertEquals(LocalDate.of(2022, 1, 1).toString(), resultDTO.getJoinedon().toString(), "The joined date does not match.");    
//    assertEquals("A1", resultDTO.getEmployeeBand(), "The employee band does not match.");  
//    assertEquals("New York", resultDTO.getLocation(), "The location does not match.");   
//    assertEquals("Software Developer", resultDTO.getRole(), "The role does not match.");
//
//}
//
//
//@Test
//public void testGetEmployeeById_NotFound() {
//
//    when(employeeRepository.findById(anyString())).thenReturn(Optional.empty());
// 
//    assertThrows(EntityNotFoundException.class, () -> {
//
//        employeeService.getEmployeeById("2");
//
//    });
//
//}
//
//
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
 
import java.time.LocalDate;
import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cognizant.dto.EmployeeDTO;
import com.cognizant.entities.Employee;
import com.cognizant.exception.EmployeeNotFoundException;
import com.cognizant.repositories.EmployeeRepository;
import com.cognizant.service.EmployeeServiceImpl;
 
public class EmployeeServiceImplTest {
	@InjectMocks
    private EmployeeServiceImpl employeeService;
    @Mock
    private EmployeeRepository employeeRepository;
 
    @BeforeEach
    public void setUp() {
    	MockitoAnnotations.openMocks(this);
//    	employeeRepository = mock(EmployeeRepository.class);
//        employeeService = new EmployeeServiceImpl();
    }
 
    @Test
    public void testGetEmployeeById_Found() throws EmployeeNotFoundException {
        // Arrange
        Employee employee = createMockEmployee();
        when(employeeRepository.findById("1")).thenReturn(Optional.of(employee));
 
        // Act
        EmployeeDTO resultDTO = employeeService.getEmployeeById("1");
 
        // Assert
        assertEmployeeDTOEqualsEmployee(employee, resultDTO);
    }
 
    @Test
    public void testGetEmployeeById_NotFound() {
        // Arrange
        when(employeeRepository.findById(anyString())).thenReturn(Optional.empty());
 
        // Act & Assert
        assertThrows(EmployeeNotFoundException.class, () -> employeeService.getEmployeeById("2"));
    }
 
    private Employee createMockEmployee() {
        Employee employee = new Employee();
        employee.setId("1");
        employee.setFirstName("John");
        employee.setLastName("Doe");
        employee.setEmail("john.doe@example.com");
        employee.setPhone("1234567890");
        employee.setJoinedon(LocalDate.of(2022, 1, 1));
        employee.setEmployeeBand("A1");
        employee.setLocation("New York");
        employee.setRole("Software Developer");
        return employee;
    }
 
    private void assertEmployeeDTOEqualsEmployee(Employee expectedEmployee, EmployeeDTO actualDTO) {
        assertEquals(expectedEmployee.getFirstName(), actualDTO.getFirstname());
        assertEquals(expectedEmployee.getLastName(), actualDTO.getLastname());
        assertEquals(expectedEmployee.getEmail(), actualDTO.getEmail());
        assertEquals(expectedEmployee.getPhone(), actualDTO.getPhone());
        assertEquals(expectedEmployee.getJoinedon(), actualDTO.getJoinedon());
        assertEquals(expectedEmployee.getEmployeeBand(), actualDTO.getEmployeeBand());
        assertEquals(expectedEmployee.getLocation(), actualDTO.getLocation());
        assertEquals(expectedEmployee.getRole(), actualDTO.getRole());
    }
}