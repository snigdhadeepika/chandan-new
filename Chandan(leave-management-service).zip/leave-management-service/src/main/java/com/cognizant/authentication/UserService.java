package com.cognizant.authentication;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.authentication.Users;
import com.cognizant.authentication.UserDTO;

public interface UserService {
	
	public List<Users> listOfUsers();
	public UserDTO authenticateUser(String username,String password);

}
