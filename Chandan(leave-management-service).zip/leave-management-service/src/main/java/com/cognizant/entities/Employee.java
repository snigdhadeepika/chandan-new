package com.cognizant.entities;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;

import jakarta.persistence.Table;

@Entity
@Table(name="Employees")
public class Employee {
	
    @Id
	@Column(name="ID")
	private String id;
	@Column(name="First_Name")
	private String firstName;
	@Column(name="Last_Name")
	private String lastName;
	@Column(name="Email")
	private String email;
	@Column(name="Phone")
	private String phone;
	@Column(name="Joined_On")
	private LocalDate joinedon;
	@Column(name="Employee_Band")
	private String employeeBand;
	@Column(name="Location")
	private String location;
	@Column(name="Role")
	private String role;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public LocalDate getJoinedon() {
		return joinedon;
	}
	public void setJoinedon(LocalDate joinedon) {
		this.joinedon = joinedon;
	}
	public String getEmployeeBand() {
		return employeeBand;
	}
	public void setEmployeeBand(String employeeBand) {
		this.employeeBand = employeeBand;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Employee(String id, String firstName, String lastName, String email, String phone, LocalDate joinedon,
			String employeeBand, String location, String role) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.joinedon = joinedon;
		this.employeeBand = employeeBand;
		this.location = location;
		this.role = role;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", phone=" + phone + ", joinedon=" + joinedon + ", employeeBand=" + employeeBand + ", location="
				+ location + ", role=" + role + "]";
	}
	
	
	
	
	

	
}
