package com.cognizant.entities;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Leaves_Register")
public class LeavesRegister {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private Integer id;
	@ManyToOne
	@JoinColumn(name="Employee_Id")
	private Employee employees;
	@Column(name="Leave_Date")
	private LocalDate leaveDate;
	@Column(name="Number_Of_Days")
	private Integer numberOfDays;
	@Column(name="Leave_Type")
	private String leaveType;
	
	public LeavesRegister(Integer id, Employee employees, LocalDate leaveDate, Integer numberOfDays,
			String leaveType) {
		super();
		this.id = id;
		this.employees = employees;
		this.leaveDate = leaveDate;
		this.numberOfDays = numberOfDays;
		this.leaveType = leaveType;
	}
	
	public LeavesRegister() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Employee getEmployees() {
		return employees;
	}
	public void setEmployees(Employee employees) {
		this.employees = employees;
	}
	public LocalDate getLeaveDate() {
		return leaveDate;
	}
	public void setLeaveDate(LocalDate leaveDate) {
		this.leaveDate = leaveDate;
	}
	public Integer getNumberofDays() {
		return numberOfDays;
	}
	public void setNumberofDays(Integer numberOfDays) {
		this.numberOfDays = numberOfDays;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	@Override
	public String toString() {
		return "LeavesRegister [id=" + id + ", employees=" + employees + ", leaveDate=" + leaveDate + ", numberOfDays="
				+ numberOfDays + ", leaveType=" + leaveType + "]";
	}

	
		
	}
	


