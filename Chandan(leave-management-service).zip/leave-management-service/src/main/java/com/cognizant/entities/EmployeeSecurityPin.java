package com.cognizant.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee_Security_PIN")
public class EmployeeSecurityPin {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private Integer Id;
	@Column(name="PIN")
	private Integer pin;
	@OneToOne
	@JoinColumn(name="Employee_ID")
	private Employee employees;
	
	
	public EmployeeSecurityPin(Integer pin, Employee employees) {
		super();
		this.pin = pin;
		this.employees = employees;
	}
	
	public EmployeeSecurityPin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	
	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public Employee getEmployees() {
		return employees;
	}
	public void setEmployees(Employee employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "EmployeeSecurityPin [Id=" + Id + ", Pin=" + pin + ", employees=" + employees + "]";
	}

}
