package com.cognizant.service;

import com.cognizant.dto.EmployeePinDTO;

public interface EmployeeSecurityPinService {
	EmployeePinDTO createEmployeeWithPIN(EmployeePinDTO employeeDto);
    String validateEmployeePIN(String employeeId, Integer pin);

}

