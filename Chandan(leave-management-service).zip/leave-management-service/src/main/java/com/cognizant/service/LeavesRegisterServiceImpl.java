package com.cognizant.service;
import com.cognizant.dto.LeaveReportDTO;
import com.cognizant.dto.LeavesRegisterDTO;
import com.cognizant.entities.Employee;
import com.cognizant.entities.LeavesRegister;
import com.cognizant.repositories.EmployeeRepository;
import com.cognizant.repositories.LeavesRegisterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.*;


@Service
public class LeavesRegisterServiceImpl implements LeavesRegisterService {
    @Autowired
    private LeavesRegisterRepository leavesRegisterRepository;
 
    @Autowired
    private EmployeeRepository employeeRepository;
 
    @Override
    public LeavesRegisterDTO addLeaveDetails(LeavesRegisterDTO leaveDto) {
        Employee employee = employeeRepository.findById(leaveDto.getEmployeeId())
            .orElseThrow(() -> new RuntimeException("Employee not found: " + leaveDto.getEmployeeId()));
 
        LeavesRegister leave = convertToEntity(leaveDto,employee);
        leave = leavesRegisterRepository.save(leave);
        return convertToDto(leave);
    }
 
  
    @Override
    public List<LeaveReportDTO> generateLeaveReport(LocalDate startDate, LocalDate endDate) {
       
    
    	
    	List<LeavesRegister> leaves = leavesRegisterRepository.findAll();
        List<LeaveReportDTO> leaveReportDTOs = new ArrayList<>();
     
        for (LeavesRegister leaveRegister : leaves) {
            LocalDate leaveStartDate = leaveRegister.getLeaveDate();
            LocalDate leaveEndDate = leaveStartDate.plusDays(leaveRegister.getNumberofDays() - 1);
     
            // Check if leave falls within the specified date range
            if (!leaveEndDate.isBefore(startDate) && !leaveStartDate.isAfter(endDate)) {
                // Calculate actual start and end dates within the range
                LocalDate actualStartDate = leaveStartDate.isBefore(startDate) ? startDate : leaveStartDate;
                LocalDate actualEndDate = leaveEndDate.isAfter(endDate) ? endDate : leaveEndDate;
     
                // Calculate number of days within the range
                int numberOfDays = (int) (ChronoUnit.DAYS.between(actualStartDate, actualEndDate) + 1);
     
                // Add leave report DTO to the list
                leaveReportDTOs.add(new LeaveReportDTO(leaveRegister.getEmployees().getId(), actualStartDate, actualEndDate, numberOfDays));
            }
        }
     
        return leaveReportDTOs;
        }
    
 
    private LeavesRegister convertToEntity(LeavesRegisterDTO dto, Employee employee) {
        LeavesRegister leave = new LeavesRegister();
        leave.setEmployees(employee);
        leave.setLeaveDate(dto.getLeaveDate()); 
       leave.setNumberofDays(dto.getNumberOfDays());
        leave.setLeaveType(dto.getLeaveType());
    
        return leave;
    }
 
    private LeavesRegisterDTO convertToDto(LeavesRegister leave) {
        LeavesRegisterDTO dto = new LeavesRegisterDTO();
        dto.setEmployeeId(leave.getEmployees().getId());
       dto.setLeaveDate(leave.getLeaveDate());
       dto.setNumberOfDays(leave.getNumberofDays());
        dto.setLeaveType(leave.getLeaveType());
        
        return dto;
    }
}


