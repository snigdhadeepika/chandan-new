
package com.cognizant.service;
import com.cognizant.dto.EmployeePinDTO;
import com.cognizant.entities.Employee;
import com.cognizant.entities.EmployeeSecurityPin;
import com.cognizant.repositories.EmployeeRepository;
import com.cognizant.repositories.EmployeeSecurityPinRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

 
@Service
public class EmployeeSecurityPinServiceImpl implements EmployeeSecurityPinService {
 
	@Autowired
    private  EmployeeRepository employeeRepository;
	@Autowired
    private  EmployeeSecurityPinRepository securityPinRepository;
 
    
 
    @Override
    public EmployeePinDTO createEmployeeWithPIN(EmployeePinDTO employeePinDto) {
        Employee employee = convertToEntity(employeePinDto);
        Employee employeeN = employeeRepository.save(employee);
        EmployeeSecurityPin pinEntity = new EmployeeSecurityPin(employeePinDto.getPin(),employeeN);
        securityPinRepository.save(pinEntity);
        return convertToDto(employeeN, pinEntity);
    }
 
    @Override
    public String validateEmployeePIN(String employeeId, Integer pin) {
    	String result="fail";
    	List<EmployeeSecurityPin>  employeeSecurityPinLIst = securityPinRepository.findAll();
        long count=employeeSecurityPinLIst
        			.stream()
        			.filter((e)->e.getEmployees().getId().equals(employeeId))
        			.filter((e)->e.getPin().intValue()==pin)
        			.count();
        	if(count==1) {
    			result="success";
        	}
        	
        
        return result;
    }
 
    private Employee convertToEntity(EmployeePinDTO dto) {
        Employee employee = new Employee();
        employee.setId(dto.getId());
        employee.setFirstName(dto.getFirstname());
        employee.setLastName(dto.getLastname());
        employee.setEmail(dto.getEmail());
        employee.setPhone(dto.getPhone());
        employee.setJoinedon(dto.getJoinedon());
        employee.setEmployeeBand(dto.getEmployeeBand());
        employee.setLocation(dto.getLocation());
        employee.setRole(dto.getRole());
       
        return employee;
    }
 
    private EmployeePinDTO convertToDto(Employee employee, EmployeeSecurityPin securityPin) {
        EmployeePinDTO dto = new EmployeePinDTO();
        dto.setId(employee.getId());
        dto.setFirstname(employee.getFirstName());
        dto.setLastname(employee.getLastName());
        dto.setEmail(employee.getEmail());
        dto.setPhone(employee.getPhone());
        dto.setJoinedon(employee.getJoinedon());
        dto.setEmployeeBand(employee.getEmployeeBand());
        dto.setLocation(employee.getLocation());
        dto.setRole(employee.getRole());
        dto.setPin(securityPin.getPin());
       
        return dto;
    }
}