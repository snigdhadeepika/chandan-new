package com.cognizant.service;

import com.cognizant.dto.EmployeeDTO;
import com.cognizant.exception.EmployeeNotFoundException;

public interface EmployeeService {
	EmployeeDTO getEmployeeById(String id) throws EmployeeNotFoundException;

}
