package com.cognizant.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cognizant.dto.EmployeeDTO;
import com.cognizant.entities.Employee;
import com.cognizant.exception.EmployeeNotFoundException;
import com.cognizant.repositories.EmployeeRepository;

//import jakarta.persistence.EntityNotFoundException;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
 
    
    @Override
    public EmployeeDTO getEmployeeById(String id) throws EmployeeNotFoundException {
        Optional<Employee> employee = employeeRepository.findById(id);
        if(employee.isEmpty()) {
            throw new EmployeeNotFoundException("Employee not found for ID: " + id);
        }
        return convertToDto(employee.get());
    }
 
    private EmployeeDTO convertToDto(Employee employee) {
        
        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(employee.getId());
        dto.setFirstname(employee.getFirstName());
        dto.setLastname(employee.getLastName());
        dto.setEmail(employee.getEmail());
        dto.setPhone(employee.getPhone());
        dto.setJoinedon(employee.getJoinedon());
        dto.setEmployeeBand(employee.getEmployeeBand());
        dto.setLocation(employee.getLocation());
        dto.setRole(employee.getRole());
       
        return dto;
    }
}
