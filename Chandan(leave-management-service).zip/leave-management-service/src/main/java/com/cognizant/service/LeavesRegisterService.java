package com.cognizant.service;
import java.time.LocalDate;
import java.util.List;

import com.cognizant.dto.LeaveReportDTO;
import com.cognizant.dto.LeavesRegisterDTO;

public interface LeavesRegisterService {
	LeavesRegisterDTO addLeaveDetails(LeavesRegisterDTO leaveDto);
	//LeaveReportDTO countEmployeeLeavesFromDate(String employeeId, LocalDate startDate, int numberOfDays);
    List<LeaveReportDTO> generateLeaveReport(LocalDate startDate, LocalDate endDate);
}
