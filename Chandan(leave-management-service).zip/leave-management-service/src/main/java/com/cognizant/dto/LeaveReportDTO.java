package com.cognizant.dto;

import java.time.LocalDate;



import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


public class LeaveReportDTO {
	@NotNull
    private String employeeId;
	@NotNull
    private LocalDate startDate;
	@NotNull
    private LocalDate endDate;
	@NotBlank
    private int leaveCount;
    
 
    public String getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}


	public LocalDate getStartDate() {
		return startDate;
	}


	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}


	public LocalDate getEndDate() {
		return endDate;
	}


	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}


	

	


	public int getLeaveCount() {
		return leaveCount;
	}


	public void setLeaveCount(int leaveCount) {
		this.leaveCount = leaveCount;
	}


	public LeaveReportDTO(@NotNull String employeeId, @NotNull LocalDate startDate, @NotNull LocalDate endDate,
			@NotBlank int leaveCount) {
		super();
		this.employeeId = employeeId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.leaveCount = leaveCount;
	}


	@Override
	public String toString() {
		return "LeaveReportDTO [employeeId=" + employeeId + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", leaveCount=" + leaveCount + "]";
	}




	


	
 
   
}
