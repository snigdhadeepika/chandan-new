package com.cognizant.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.*;

public class LeavesRegisterDTO {
	
	@NotNull
	private String employeeId;
	@NotNull
	private LocalDate leaveDate;
	@NotNull
	@Min(1)
	private Integer numberOfDays;
	@NotBlank
	@Pattern(regexp = "^(Sick|Annual|Personal)$", message = "Invalid leave type")
	private String leaveType;
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public LocalDate getLeaveDate() {
		return leaveDate;
	}
	public void setLeaveDate(LocalDate leaveDate) {
		this.leaveDate = leaveDate;
	}
	public Integer getNumberOfDays() {
		return numberOfDays;
	}
	public void setNumberOfDays(Integer numberOfDays) {
		this.numberOfDays = numberOfDays;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public LeavesRegisterDTO( @NotNull String employeeId, @NotNull LocalDate leaveDate,
			@NotNull @Min(1) Integer numberOfDays,
			@NotBlank @Pattern(regexp = "^(Sick|Annual|Personal)$", message = "Invalid leave type") String leaveType) {
		super();
		this.employeeId = employeeId;
		this.leaveDate = leaveDate;
		this.numberOfDays = numberOfDays;
		this.leaveType = leaveType;
	}
	public LeavesRegisterDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LeavesRegisterDTO [employeeId=" + employeeId + ", leaveDate=" + leaveDate
				+ ", numberOfDays=" + numberOfDays + ", leaveType=" + leaveType + "]";
	}
	
	
	

}
