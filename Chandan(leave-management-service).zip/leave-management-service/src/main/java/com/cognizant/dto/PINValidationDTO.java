package com.cognizant.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class PINValidationDTO {
	
    private String employeeId;
    @NotBlank
	@Size(min=4,max=4, message="PIN must be exactly 4 digits")
    private Integer pin;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(Integer pin) {
		this.pin = pin;
	}
	public PINValidationDTO(String employeeId, Integer pin) {
		super();
		this.employeeId = employeeId;
		this.pin = pin;
	}
	@Override
	public String toString() {
		return "PINValidationDTO [employeeId=" + employeeId + ", pin=" + pin + "]";
	}
 
    
}