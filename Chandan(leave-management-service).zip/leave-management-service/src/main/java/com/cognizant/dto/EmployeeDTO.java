package com.cognizant.dto;

import java.time.LocalDate;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Email;

public class EmployeeDTO {
	@NotNull
	@Size(max=10)
	private String Id;
	@NotBlank
	@Size(max=50)
	private String Firstname;
	@NotBlank
	@Size(max=50)
	private String Lastname;
	@Email
	@NotBlank
	private String Email;
	@NotBlank
	@Pattern(regexp = "\\d{10}", message = "Phone must be exactly 10 digits")
	private String Phone;
	@NotNull
	private LocalDate Joinedon;
	@NotBlank
	@Pattern(regexp = "^(A1|A2|B1|B2|C1|C2|L1|L2)$", message = "Invalid employee band")
	private String EmployeeBand;
	@NotBlank
	@Pattern(regexp = "^(Hyderabad|Pune|Chennai|Bengaluru)$", message = "Invalid location")
	private String Location;
	@NotBlank
	private String Role;
	
		public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public LocalDate getJoinedon() {
		return Joinedon;
	}
	public void setJoinedon(LocalDate joinedon) {
		Joinedon = joinedon;
	}
	public String getEmployeeBand() {
		return EmployeeBand;
	}
	public void setEmployeeBand(String employeeBand) {
		EmployeeBand = employeeBand;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
}
	