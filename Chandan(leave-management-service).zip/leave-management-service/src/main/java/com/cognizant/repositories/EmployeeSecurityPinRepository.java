package com.cognizant.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cognizant.entities.EmployeeSecurityPin;

public interface EmployeeSecurityPinRepository extends JpaRepository <EmployeeSecurityPin,Integer> {

	
	//EmployeeSecurityPin findByEmployeeId(String employees);

}
