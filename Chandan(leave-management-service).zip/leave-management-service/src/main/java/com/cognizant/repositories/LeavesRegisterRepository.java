package com.cognizant.repositories;

import com.cognizant.entities.LeavesRegister;

import org.springframework.data.jpa.repository.JpaRepository;


 
public interface LeavesRegisterRepository extends JpaRepository<LeavesRegister, Integer> {
 

}