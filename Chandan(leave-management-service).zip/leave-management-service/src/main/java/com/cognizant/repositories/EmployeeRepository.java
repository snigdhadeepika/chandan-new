package com.cognizant.repositories;
import org.springframework.data.jpa.repository.JpaRepository;


import com.cognizant.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,String> {

}
