package com.cognizant.controller;
import com.cognizant.dto.EmployeePinDTO;
import com.cognizant.service.EmployeeSecurityPinService;

import jakarta.validation.Valid;

//import jakarta.persistence.EntityNotFoundException;
//import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:4200/")
 
@RestController
@RequestMapping("/api/employees")
public class EmployeeSecurityPinController {
    @Autowired
    private EmployeeSecurityPinService employeeSecurityPinService;
 
   
 
    @PostMapping("/add")
    public ResponseEntity<EmployeePinDTO> createEmployeeWithPIN(@Valid @RequestBody EmployeePinDTO employeePinDto) {
    	
        EmployeePinDTO savedEmployeePinDto = employeeSecurityPinService.createEmployeeWithPIN(employeePinDto);
        
        return ResponseEntity.ok(savedEmployeePinDto);
    }
 
    @PostMapping("/validatePin")
    public ResponseEntity<?> validateEmployeePIN(@RequestParam String employeeId, @RequestParam Integer pin) {
        
           String result= employeeSecurityPinService.validateEmployeePIN(employeeId, pin);
            if(result.equals("success")) {
                return ResponseEntity.ok().body("PIN validation successful.");

            }else {
                return new ResponseEntity<>("NOT FOUND",HttpStatus.BAD_REQUEST);

            }
    }
    
}
