package com.cognizant.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.dto.EmployeeDTO;

import com.cognizant.exception.EmployeeNotFoundException;
import com.cognizant.service.EmployeeService;




@CrossOrigin("http://localhost:4200/")
@RestController
@RequestMapping("/api")


public class employeeController {
	Logger logger
    = LoggerFactory.getLogger(employeeController.class);
	
	
@Autowired
private EmployeeService employeeService;
  @GetMapping("/employees/{id}")
  public ResponseEntity<?> getEmployee(@PathVariable String id){
	  
     EmployeeDTO employeeDTO;
	try {
		logger.info("Log level: INFO");
		employeeDTO = employeeService.getEmployeeById(id);
		return new ResponseEntity<EmployeeDTO> (employeeDTO, HttpStatus.OK);
	} catch (EmployeeNotFoundException e) {
		return new ResponseEntity<>("employeee not found",HttpStatus.BAD_REQUEST);
	}
  }
};