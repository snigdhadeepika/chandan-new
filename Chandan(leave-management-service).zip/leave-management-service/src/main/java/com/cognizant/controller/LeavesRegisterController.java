package com.cognizant.controller;
import com.cognizant.dto.LeaveReportDTO;
import com.cognizant.dto.LeavesRegisterDTO;
import com.cognizant.service.LeavesRegisterService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import java.time.LocalDate;
import java.util.List;
@CrossOrigin("http://localhost:4200/")
@RestController
@RequestMapping("/api/leaves")
public class LeavesRegisterController {
	
    @Autowired
    private LeavesRegisterService leavesRegisterService;
 
 
    @PostMapping("/add")
    public ResponseEntity<LeavesRegisterDTO> addLeave(@Valid @RequestBody LeavesRegisterDTO leaveDto) {
    	System.out.println(leaveDto.toString());
        LeavesRegisterDTO savedLeaveDto = leavesRegisterService.addLeaveDetails(leaveDto);
        return ResponseEntity.ok(savedLeaveDto);
    }
 
    @GetMapping("/report")
    public ResponseEntity<List<LeaveReportDTO>> getLeaveReport(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        List<LeaveReportDTO> reports = leavesRegisterService.generateLeaveReport(startDate, endDate);
       
        return ResponseEntity.ok(reports);
    }
 
   
}