insert into users values('saras','saras123','admin',false);
insert into users values('chandan','saras123','user',false);