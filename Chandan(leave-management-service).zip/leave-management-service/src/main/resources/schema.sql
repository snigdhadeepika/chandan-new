CREATE TABLE Employees (

    ID VARCHAR(10) PRIMARY KEY,

    First_Name VARCHAR(50),

    Last_Name VARCHAR(50),

    Email VARCHAR(255),

    Phone VARCHAR(10),

    Joined_On DATE,

    Employee_Band VARCHAR(2),

    Location VARCHAR(50),

    Role VARCHAR(20)

);
 
-- SQL schema for LeaveRegister table

CREATE TABLE Leaves_Register (

    ID BIGINT PRIMARY KEY AUTO_INCREMENT,

    Employee_ID VARCHAR(10),

    Leave_Date DATE,

    Number_Of_Days INT,

    Leave_Type VARCHAR(20),

    CONSTRAINT fk_EmployeeID FOREIGN KEY (Employee_ID) REFERENCES Employees(ID)

);
 
-- SQL schema for EmployeeSecurityPIN table

CREATE TABLE Employee_Security_PIN (
    ID BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    Employee_ID VARCHAR(10),

    PIN INT,

    CONSTRAINT fk_EmployeeSecurityPIN_EmployeeID FOREIGN KEY (Employee_ID) REFERENCES Employees(ID)

);
create table users(
user_name varchar(40),
password varchar(40) not null,
role varchar(40) not null,
is_Account_Locked boolean
);