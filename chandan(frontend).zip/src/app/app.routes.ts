import { Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { AddLeaveComponent } from './components/add-leave/add-leave.component';
import { HomeComponent } from './components/home/home.component';
import { LeaveReportComponent } from './components/leave-report/leave-report.component';
import { LoginComponent } from './components/login/login.component';
import { ViewEmployeeByIdComponent } from './components/view-employee-by-id/view-employee-by-id.component';


export const routes: Routes = [

    {
        path:"addEmployee",
        component:AddEmployeeComponent

    },
    {
        path:"viewEmployee",
        component:ViewEmployeeByIdComponent

    },
    {
        path:"leaveReport",
        component:LeaveReportComponent

    },
    {
        path:"addLeave",
        component:AddLeaveComponent

    },
    {
        path:"",
        component:HomeComponent
    },
    
   
];
