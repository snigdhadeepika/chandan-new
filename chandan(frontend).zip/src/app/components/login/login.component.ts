import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../models/User';
import { AuthenticationService } from '../../services/authentication.service';
import { HeaderComponent } from '../header/header.component';



@Component({
  selector: 'app-login',
  standalone: true,
  imports:[FormsModule,CommonModule,HeaderComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

export class LoginComponent{

  username= ''
  password= ''
  invalidLogin= false;
  user:User={
    userName: "",
    password: "",
    role: "",
    isAccountLocked:false,
  }
  

  constructor(private router:Router,private loginservice: AuthenticationService){
  
  }

  checkLogin() {
    this.loginservice.authenticate(this.username, this.password).subscribe(isAuthenticated => {
        if (isAuthenticated) {
            this.router.navigate(['/app']);
        } else {
            this.invalidLogin = true;
            this.username = '';
            this.password = '';
            window.alert('Invalid username or password. Please try again.')
        }
    });
}

}

