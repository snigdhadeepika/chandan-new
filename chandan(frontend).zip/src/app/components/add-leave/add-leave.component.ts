import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { LeavesRegister } from '../../models/LeavesRegister';
import { LeavesRegisterService } from '../../services/leaves-register.service';

@Component({
  selector: 'app-add-leave',
  standalone: true,
  imports: [FormsModule,CommonModule,RouterLink],
  templateUrl: './add-leave.component.html',
  styleUrl: './add-leave.component.css'
})
export class AddLeaveComponent {
  leavesregister:LeavesRegister ={
    employeeId:"",
    leaveDate:new Date(),
    numberOfDays:0,
    leaveType:"",
  }
  constructor(private leavesregisterService:LeavesRegisterService)
  {

  }
 
  onSubmit()
  {
    console.log("formsubmitted");
    console.log(this.leavesregister);
    this.leavesregisterService.addleave(this.leavesregister).subscribe(data=>{
      alert("leaves saved successfully");
      
    })
    
  }

}
