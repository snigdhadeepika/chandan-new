import { Component } from '@angular/core';
import { Employee } from '../../models/Employee';
import { FormsModule, } from '@angular/forms';
import { EmployeeService } from '../../services/employee.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-employee',
  standalone: true,
  imports: [FormsModule,CommonModule, ],
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css'
})
export class AddEmployeeComponent {
  employee:Employee={
   id:"",
    firstname:"",
    lastname:"",
    email:"",
    phone:"",
    joinedon:new Date(),
    employeeBand:"",
    location:"",
    role:"",
    pin:0,
  }
  constructor(private employeeService:EmployeeService,router:Router)
  {

  }
 
  onSubmit()
  
  {
    console.log("formsubmitted");
    console.log(this.employee);
    
    this.employeeService.addEmployee(this.employee).subscribe(data=>{
      alert("employee saved successfully");
    })
    
  }

}
