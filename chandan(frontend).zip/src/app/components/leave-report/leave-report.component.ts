import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { LeaveReport ,LeaveReports} from '../../models/LeaveReport';
import { LeavesRegisterService } from '../../services/leaves-register.service';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-leave-report',
  standalone: true,
  imports: [FormsModule,CommonModule,],
  templateUrl: './leave-report.component.html',
  styleUrl: './leave-report.component.css'
})
export class LeaveReportComponent {
  leavereport:LeaveReport={
    startDate:new Date(),
    endDate:new Date(),
    leaveCount:0,
    employeeId:"",
  }
  leavereports:LeaveReport[]=[];

  
  constructor(private leavesregisterService:LeavesRegisterService)
  {

  }
 
  onSubmit()
  {
    console.log("formsubmitted");
    
    this.leavesregisterService.getreport(this.leavereport).subscribe(data=>{
      
      console.log(data);
      
      this.leavereports=data;
      console.log("formsss");
     // console.log(this.leavereport);
     
      console.log(this.leavereports);
      
      
    }
    
    )
    
  }

}
