import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive, RouterModule } from '@angular/router';
import { Employee } from '../../models/Employee';
import { EmployeeService } from '../../services/employee.service';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-view-employee-by-id',
  standalone: true,
  imports: [FormsModule,HeaderComponent,RouterModule,RouterLinkActive,RouterLink],
  templateUrl: './view-employee-by-id.component.html',
  styleUrl: './view-employee-by-id.component.css'
})
export class ViewEmployeeByIdComponent {

  employeeNotFoundMessage!:any;
  constructor(private employeeService:EmployeeService,router:Router)
  {

  }
  employee:Employee={
     id:"",
     firstname:"",
     lastname:"",
     email:"",
     phone:"",
     joinedon:new Date(),
     employeeBand:"",
     location:"",
     role:"",
     pin:0,
  }
  
  onSubmit()
  {
    console.log("employee id :")
    console.log(this.employee.id);
    this.employeeService.getEmployeeById(this.employee).subscribe(data=>
      {
        this.employee=data;
        console.log(data);
    },
    error => {
      alert("Employee Not Found");
      }
  
    
    
    )
    console.log(Error);
    
    
  }

}
