export interface LeavesRegister{
    
    "employeeId":string,
    "leaveDate":Date,
    "numberOfDays":number,
    "leaveType":string,
}