export interface Employee{
    id: string;
    firstname: string;
    lastname: string;
    email: string;
    phone: string;
    joinedon: Date;
    employeeBand: string;
    location:string;
    role:string;
    pin:number;
  
}