export interface LeaveReport{
    "startDate":Date,
    "endDate":Date,
    "leaveCount":number,
    "employeeId":string,
    
}
export interface LeaveReports{
    "startDate":Date,
    "endDate":Date,
    "leaveCount":number,
    "employeeId":string,
}