export interface User {
    userName: string ;
    password: string ;
    role: string ;
    isAccountLocked:boolean ;
}