import { HttpClient } from '@angular/common/http';
import { BootstrapOptions, Injectable } from '@angular/core';
import { first, Observable } from 'rxjs';
import { User } from '../models/User';



@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http:HttpClient) { }

  private authenticationURL:string="http://localhost:8091/authenticate/users";

  user: User={
    userName: "",
    password: "",
    role: "",
    isAccountLocked: false,
  }
  userBackend: User={
    userName: "",
    password: "",
    role: "",
    isAccountLocked: false,

  }
  authenticated:boolean | undefined;

  
authenticate(username: string, password: string): Observable<boolean> {
    this.user = {
      userName: "",
    password: "",
    role: "",
    isAccountLocked: false,
    }
    console.log(username);
    console.log(password);
    this.user.userName = username;
    this.user.password = password;

  return new Observable<boolean>((observer) => {
        this.getUser(this.user).pipe(first()).subscribe((data) => {

            this.userBackend = {

              userName: "",
    password: "",
    role: "",
    isAccountLocked: false,

            }
            console.log(data);
            this.userBackend.userName = data.userName;
            this.userBackend.password = data.password;
            this.userBackend.role = data.role;
            if (this.user.userName === this.userBackend.userName && this.user.password == this.userBackend.password) {
                this.authenticated = true;
                sessionStorage.setItem('username', username);
                sessionStorage.setItem('role', this.userBackend.role);
            } else {
                this.authenticated = false;
            }
            observer.next(this.authenticated);
            observer.complete();
        });
    });
}


getUser(user: any){
    return this.http.post<User>(this.authenticationURL, user);
}

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    let role=sessionStorage.getItem('role');
    console.log(!(user === null))
    return !(user === null && role===null);

  }

  isUserMotorist(){
    let role=sessionStorage.getItem('role');
    return (role==='Motorist');
  }

  isUserNotMotorist(){
    let role=sessionStorage.getItem('role');
    return (role==='Rider');
  }

  
  logOut() {
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('role');
  }
}
