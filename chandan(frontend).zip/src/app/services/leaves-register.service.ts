import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LeaveReport, LeaveReports } from '../models/LeaveReport';
import { LeavesRegister } from '../models/LeavesRegister';

@Injectable({
  providedIn: 'root'
})
export class LeavesRegisterService {

  
  
  private addleaveURL='http://localhost:8091/api/leaves/add';
  private getleavereportURL='http://localhost:8091/api/leaves/report';
  constructor(private http:HttpClient) { }
  public addleave(leavesregister:LeavesRegister)
  {
    return this.http.post<LeavesRegister>(this.addleaveURL,leavesregister);
    
  }
  public getreport(leavereport:LeaveReport)
  {
    return this.http.get<LeaveReport[]>(this.getleavereportURL+'?'+'startDate='+leavereport.startDate+'&'+'endDate='+leavereport.endDate);
  }
  
}

