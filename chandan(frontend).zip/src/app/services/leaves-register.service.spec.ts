import { TestBed } from '@angular/core/testing';

import { LeavesRegisterService } from './leaves-register.service';

describe('LeavesRegisterService', () => {
  let service: LeavesRegisterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LeavesRegisterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
