import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../models/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  private registerEmployeesURL='http://localhost:8091/api/employees/add';
  private retrieveEmployeeByIdURL='http://localhost:8091/api/employees';

  constructor(private http:HttpClient) { }
  public addEmployee(employee:Employee)
  {
    return this.http.post<Employee>(this.registerEmployeesURL,employee);
    
  }
  public getEmployeeById(employee:Employee){
    
  return this.http.get<Employee>(this.retrieveEmployeeByIdURL+'/'+employee.id);
  }
}
