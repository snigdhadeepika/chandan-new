import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { AddLeaveComponent } from './components/add-leave/add-leave.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { LeaveReportComponent } from './components/leave-report/leave-report.component';
import { LoginComponent } from './components/login/login.component';
import { ViewEmployeeByIdComponent } from './components/view-employee-by-id/view-employee-by-id.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, AddEmployeeComponent, ViewEmployeeByIdComponent, LeaveReportComponent, AddLeaveComponent, FormsModule, RouterModule,LoginComponent,HeaderComponent,HomeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'leave-managementUI';
}
